//
//  MainViewController.h
//  ZazaBeat
//
//  Created by Gohar on 6/16/18.
//  Copyright © 2018 Gohar Vardanyan. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MainViewController : UIViewController

@end

