//
//  ProjectsView.m
//  ZazaBeat
//
//  Created by Gohar Vardanyan on 6/14/18.
//  Copyright © 2018 Gohar Vardanyan. All rights reserved.
//

#import "ProjectsView.h"
#import "FrameManager.h"

@interface ProjectsView()

@property (strong, nonatomic) IBOutlet ProjectsView *contentView;

@end

@implementation ProjectsView

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
    [[NSBundle mainBundle] loadNibNamed:@"ProjectsView" owner:self options:nil];
        
        self.tag = 2;
        self.isFullScreen = YES;
        self.contentView.frame = self.frame;
        
        [self addSubview:self.contentView];
    }
    return self;
}

#pragma mark - Button Actions

- (IBAction)burgerButtonActionn:(UIButton *)sender {
    FrameManager *frameManager = [[FrameManager alloc] init];
    self.isFullScreen = [frameManager frameForView:self isFullScreen:self.isFullScreen withCompletion:nil];
}

@end
