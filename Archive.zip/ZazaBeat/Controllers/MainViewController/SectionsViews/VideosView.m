//
//  VideosView.m
//  ZazaBeat
//
//  Created by Gohar Vardanyan on 6/15/18.
//  Copyright © 2018 Gohar Vardanyan. All rights reserved.
//

#import "VideosView.h"
//#import "UIView+Frame.h"
#import "FrameManager.h"

@interface VideosView()

@property (strong, nonatomic) IBOutlet VideosView *contentView;

@end

@implementation VideosView

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        [[NSBundle mainBundle] loadNibNamed:@"VideosView" owner:self options:nil];
    
        self.tag = 6;
        self.contentView.frame = self.frame;
        self.isFullScreen = YES;

        [self addSubview:self.contentView];
    }
    return self;
}

- (IBAction)burgerButtonAction:(UIButton *)sender {
    FrameManager *frameManager = [[FrameManager alloc] init];
    self.isFullScreen = [frameManager frameForView:self isFullScreen:self.isFullScreen withCompletion:nil];
}

@end
