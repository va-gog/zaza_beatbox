//
//  VideosView.h
//  ZazaBeat
//
//  Created by Gohar Vardanyan on 6/15/18.
//  Copyright © 2018 Gohar Vardanyan. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface VideosView : UIView

@property (assign, nonatomic) BOOL isFullScreen;

@end
