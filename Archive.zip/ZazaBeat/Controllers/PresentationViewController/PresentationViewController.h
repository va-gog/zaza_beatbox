//
//  PresentationViewController.h
//  ZazaBeat
//
//  Created by Gohar on 6/20/18.
//  Copyright © 2018 Gohar Vardanyan. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PresentationViewController : UIViewController

@end
